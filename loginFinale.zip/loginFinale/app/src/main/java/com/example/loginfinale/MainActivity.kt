package com.example.loginfinale

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {
    private lateinit var signUp: TextView
    private lateinit var logIn: TextView
    private lateinit var signUpLayout: LinearLayout
    private lateinit var logInLayout: LinearLayout
    private lateinit var eMail: EditText
    private lateinit var password: EditText
    private lateinit var confirmpass: EditText
    private lateinit var eMails: EditText
    private lateinit var passwords: EditText

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        init()
        registerListeners()
        loginListeners()
    }


    private fun init() {
        signUp = findViewById(R.id.signUp)
        logIn = findViewById(R.id.logIn)
        signUpLayout = findViewById(R.id.signUpLayout)
        logInLayout = findViewById(R.id.logInLayout)
        eMail = findViewById(R.id.eMail)
        password = findViewById(R.id.passwords)
        confirmpass = findViewById(R.id.confirmPass)
        eMails = findViewById(R.id.eMails)
        passwords = findViewById(R.id.passwords)
    }


    @RequiresApi(Build.VERSION_CODES.M)
    private fun registerListeners() {
        signUp.setOnClickListener {
            val emails = eMails.text.toString()
            val password = password.text.toString()
            val confirmpass = confirmpass.text.toString()
            signUp.background = resources.getDrawable(R.drawable.switch_trcks, null)
            signUp.setTextColor(resources.getColor(R.color.textColor, null))
            logIn.background = null
            signUpLayout.visibility = View.VISIBLE
            logInLayout.visibility = View.GONE
            logIn.setTextColor(resources.getColor(R.color.pinkColor, null))
            if (emails.isEmpty() || password.isEmpty() || confirmpass.isEmpty()) {
                Toast.makeText(this, "Empty", Toast.LENGTH_SHORT).show()
                return@setOnClickListener

            }
            FirebaseAuth.getInstance().createUserWithEmailAndPassword(emails, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "თქვენ წარმატებით დარეგისტრირდით!", Toast.LENGTH_SHORT)
                            .show()
                    } else {
                        Toast.makeText(this, "შეიყვანეთ პარამეტრები სწორად", Toast.LENGTH_SHORT)
                            .show()
                    }
                }
        }
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun loginListeners() {

        logIn.setOnClickListener {
            val eMail = eMail.text.toString()
            val passwords = passwords.text.toString()
            if (eMail.isEmpty() || passwords.isEmpty()) {
                Toast.makeText(this, "Empty", Toast.LENGTH_SHORT).show()
                return@setOnClickListener

                FirebaseAuth.getInstance().signInWithEmailAndPassword(eMail, passwords)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            Toast.makeText(this, "S", Toast.LENGTH_SHORT).show()

                        }
                    }
            }
            signUp.background = null
            signUp.setTextColor(resources.getColor(R.color.pinkColor, null))
            logIn.background = resources.getDrawable(R.drawable.switch_trcks, null)
            signUpLayout.visibility = View.GONE
            logInLayout.visibility = View.VISIBLE
            logIn.setTextColor(resources.getColor(R.color.textColor, null))
        }


    }
}